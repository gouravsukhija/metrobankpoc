 var host = context.getVariable("Mock-CBS-EndPoint");
 var suffix = context.getVariable("proxy.pathsuffix");
 var newURL = host.concat("/getAccountBalance");
 context.setVariable("target.url",newURL);