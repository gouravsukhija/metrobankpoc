 function createGetAccountResponse(){
     var response=context.getVariable("response.content");
     
     var parsedResponse=JSON.parse(response);
     print(response);
     var body=parsedResponse.Envelope.Body.GetAccountBalanceResponse;
     var myresponse={
         "accountNumber":body.AccountNumber.toString(),
         "currentCode":body.Currency,
         "amount":body.Balance.toString()
     };
     
     context.setVariable("response.content",JSON.stringify(myresponse));
 }
 
 createGetAccountResponse();